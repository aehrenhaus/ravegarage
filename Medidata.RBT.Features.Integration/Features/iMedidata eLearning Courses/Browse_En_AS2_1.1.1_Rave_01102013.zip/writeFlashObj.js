function printFlash(){
	/*document.write('')
	document.write('<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="https://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="1004" height="657" id="shell" align="middle">')
	document.write('<param name="allowScriptAccess" value="always" />')
	document.write('<param name="movie" value="wrapper.swf" />')
	var vidSTR = document.location.href
	var vidURL=vidSTR.split("?")
	document.write('<PARAM NAME=FlashVars VALUE="flashKaVar='+vidURL[1]+'">')
	document.write('<param name="quality" value="high" />')
	document.write('<param name="bgcolor" value="#FFFFFF" />')
	document.write('<param name="menu" value="false" />')
	document.write('<embed src="wrapper.swf" name ="shell" swliveconnect="true" FlashVars="flashKaVar='+vidURL[1]+'" menu="false" quality="high" allowfullscreen="true" bgcolor="#FFFFFF" width="1004" height="657" name="shell" align="middle" allowScriptAccess="always" type="application/x-shockwave-flash" pluginspage="https://www.macromedia.com/go/getflashplayer" /></object>')
	document.write('')*/
	var data='<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="https://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="1004" height="657" id="shell" align="middle"><param name="allowScriptAccess" value="always" /><param name="movie" value="wrapper.swf" />'
	var vidSTR = document.location.href;
	var vidURL=vidSTR.split("?")
	data+='<PARAM NAME=FlashVars VALUE="flashKaVar='+vidURL[1]+'"><param name="quality" value="high" /> <param name="bgcolor" value="#FFFFFF" /><param name="menu" value="false" /><embed src="wrapper.swf" name ="shell" ID = "embedShell" swliveconnect="true" FlashVars="flashKaVar='+vidURL[1]+'" menu="false" quality="high" allowfullscreen="true" bgcolor="#FFFFFF" width="1004" height="657" name="shell" align="middle" allowScriptAccess="always" type="application/x-shockwave-flash" pluginspage="https://www.macromedia.com/go/getflashplayer" /></object><iframe name="googleFrame" id="googleFrame" frameborder="0" scrolling="no" width="100%" style="display:none;" ></iframe><iframe name="googleFrame1" id="googleFrame1" frameborder="0" scrolling="no" width="100%" style="display:none;" onload = "postedAndClose()"></iframe><iframe name="questForm" id="questForm" frameborder="0" scrolling="no" width="100%" style="display:none;"></iframe>'
	document.body.innerHTML=data
	document.getElementById('shell').focus() 
	
		
}

function printHTML(version){
	if(String(courseType).toLowerCase()!="scorm"){
		closeParentWindow()
	}
	var requiredVersion=String(playerVersion).split(".")
	var data="<tr><td align='center'><font face='Arial' color='#000000' size='2'>"+String(failureMessage).split("[version]").join(requiredVersion[0])+"</font></td></tr>";
	if(version=="-1"){
		data+="<tr><td align='center'><font face='Arial' color='#000000' size='2'>"+notFound+"</font></td></tr>";
	}else{
		data+="<tr><td align='center'><font face='Arial' color='#000000' size='2'>"+String(lowerVersion).split("[version]").join(version);+"</font></td></tr>";
	}
	data+="<tr><td align='center'><font face='Arial' color='#000000' size='2'>"+linkInstruction+"</font></td></tr>";
	data+="<tr><td align='center'><font face='Arial' color='#000000' size='2'>"+linkURL+"</font></td></tr>";
	

	document.body.innerHTML="<table width='100%'><tr><td height='600'><table align='center' width='60%' height='100' border='1' bordercolor='#91acd1' bgcolor='#f9fafc' cellpadding='3' cellspacing='1'>"+data+"</table></td></tr></table>"
	
}