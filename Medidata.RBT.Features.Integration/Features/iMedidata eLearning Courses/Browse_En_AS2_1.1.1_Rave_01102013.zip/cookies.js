//var URLStr = document.location.href
//var courseNameStr=URLStr.split("?")[1].split(",")[0]
//var courseLocaleStr=URLStr.split("?")[1].split(",")[3]
//var cookieNameStr = courseNameStr + "_" + courseLocaleStr
//alert(cookieNameStr)
//var cookie_name = cookieNameStr
var cookie_name = "courseCurriculum"

var bookmarkCookieData=""

function getCookieData() {
  if(document.cookie) {
     index = document.cookie.indexOf(cookie_name);
     if (index != -1) {
       countbegin = (document.cookie.indexOf("=", index) + 1);
       countend = document.cookie.indexOf(";", index);
       if (countend == -1) {
         countend = document.cookie.length;
       }
       bookmarkCookieData = document.cookie.substring(countbegin, countend);
     }
   }
myINT = setInterval("sendDataToFlash()" , 100)
}

//var cookie_name = "bookmarkCookie";

function sendData(userData){
	setCookieData(userData)
}

function setCookieData(vBookmarkData) {
  if(document.cookie) {
	index = document.cookie.indexOf(cookie_name);
  } else {
    index = -1;
  }

  if (index == -1) {
	document.cookie=cookie_name+"="+vBookmarkData+"; expires=Wednesday, 01-Aug-2040 08:00:00 GMT";
  } else {
    countbegin = (document.cookie.indexOf("=", index) + 1);
    countend = document.cookie.indexOf(";", index);
    if (countend == -1) {
      countend = document.cookie.length;
    }
    //count = eval(document.cookie.substring(countbegin, countend)) + 1;
    document.cookie=cookie_name+"="+vBookmarkData+"; expires=Wednesday, 01-Aug-2040 08:00:00 GMT";
  }

  //alert("vBookmarkData: "+vBookmarkData)
}


function sendDataToFlash(){
	try{
		if (document.all){
				flashObj = document.getElementById("shell");
			}else{
				flashObj = document.shell;
		}

		var frameStatus = new Array()
		flashObj.SetVariable("lmsData",bookmarkCookieData);
		flashObj.SetVariable("lmsDataArrived", "yes");
		clearInterval(myINT)
		//alert('sssss')
		}
		catch(e) {
			//alert("not found ")
	}
}