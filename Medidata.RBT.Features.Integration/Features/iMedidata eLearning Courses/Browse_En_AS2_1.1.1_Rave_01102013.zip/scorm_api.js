var Ap;
var findAPITries=1;
var API = null;
var lsnInfo = null;
var lsnStatus;
var totalScore;
var oldScore;
var vLesson;
var mastery_score;
var inatrval;
var DebugContent
var flashObj;
var status="";
var score;
var seperator = "<br>=====================================================================<br>";
var resultPageGlobal = false
var alreadyCompleted = false
function trace(content)//
{
	return;
	debugWin1 = window.open("", "debugWin1", "menubar=no, fullscreen=no, width=500, height=300, scrollbars=yes,resize=yes")
	debugWin1.resizeTo(screen.width, 400);	
	debugWin1.document.open();
	debugWin1.document.write(content);
	//debugWin.document.close();	
}

function FindAPI(win)
{
	
   while ((win.API == null) && (win.parent != null) && (win.parent != win))
   {
      findAPITries++;
      // Note: 7 is an arbitrary number, but should be more than sufficient
      if (findAPITries > 7) 
      {
        parent.status = "Error finding API -- too deeply nested.";
        //alert('API not found')
	//////////////
	DebugContent += "API not Found : " + findAPITries +seperator;
	trace(DebugContent);
        /////////////
	return null;
      }else{
	//////////////
	DebugContent += "API Found"+ win.API +seperator;
	trace(DebugContent);
        /////////////
     }
      win = win.parent;

   }
   return win.API;
}

function GetAPI()
{
	var sTime = new Date().getTime();
   var API = FindAPI(window);
 
   if ((API == null) && (window.opener != null) && (typeof(window.opener) != "undefined"))
   {
      API = FindAPI(window.opener);
   }
   if (API == null)
   {
     parent.status = "Unable to find an API adapter";
   }
	var eTime = new Date().getTime();
	var elapsedTime=((eTime-sTime)/1000)
	strToFlash = "Function: GetAPI <br>API: "+API+"<br>Elapsed Time: "+elapsedTime+"<br>Start Time: "+sTime+"<br>End Time: "+eTime+"<br>"
	fnDebuggerSetData(strToFlash, "other")
   return API
}


function initSco(){

	if (document.all){
		flashObj = document.getElementById("shell");
	}else{
		flashObj = document.shell;
	}
	API = GetAPI();
	if( API != null )
	{
		//code added for debugger
		var startTime = new Date().getTime();
		var retValue = API.LMSInitialize("");	
		var endTime = new Date().getTime();
		showTime("API.LMSInitialize", " ",  retValue, startTime, endTime);
		///
		startTimer();
		set_val("cmi.core.session_time","0000:00:00");
		mastery_score = get_val("cmi.student_data.mastery_score");
		if(mastery_score == null || mastery_score == "" ){
		mastery_score = 80
		}
		set_val("cmi.core.lesson_status","incomplete");
		lsnStatus = "incomplete"
		suspendData=fnGetVSection()
		tmp_arr=suspendData.split("$$$")
		suspendData=tmp_arr[0]
		status=tmp_arr[1]
		if(status == "completed"){
			alreadyCompleted = true
		}
		intFlash();
		
		//code = API.LMSGetLastError();
		//ret = API.LMSGetErrorString( code );
		//diag = API.LMSGetDiagnostic( "" );
	}else{
		
		flashObj.SetVariable("lmsInitData", "true");
		
	}
}

function intFlash(){
	flashObj.SetVariable("lmsSuspendData", suspendData);
	flashObj.SetVariable("lmsLessonStatus", status);
	//flashObj.SetVariable("lmsLessonStatus", "completed");
	//flashObj.SetVariable("lmsSuspendData", "111111100000000#1_5#false#0");
	flashObj.SetVariable("lmsStudentMasteryScore", mastery_score);
	flashObj.SetVariable("lmsInitData", "true");
	flashObj.SetVariable("lmsStudentName", fnGetStudentName());
	
	
}

function set_val( gname,gvalue ){
		
	if(gvalue == null || gvalue == "undefined" || gvalue == ""){
		return;
	}
	GetAPI();
	if( API != null )
	{
		//code added for external debugger//
		var ret;
		var code;
		var diag;		
		
		var startTime = new Date().getTime();
		var ret=API.LMSSetValue( gname, gvalue );
		var endTime = new Date().getTime();
		/*
		if(gvalue.indexOf("<") != -1){
			gvalue = gvalue.split("<").join("&#60;");
		} */
	//alert("set_val")
		showTime("API.LMSSetValue", gname,  ret, startTime, endTime, gvalue)
		//--------------//	
		
	}

};

function get_val( gname )
{	
//alert(gname)
if (gname=="cmi.core.session_time") return "00:00:00";
	GetAPI();
	if( API != null )
	{
		//code added for external debugger//
			var ret1,ret2;
			var code;
			var diag;	
			var startTime = new Date().getTime();		
			ret1 = API.LMSGetValue( gname );
			var endTime = new Date().getTime();
			
			
		
			var returnVal = String(ret1);		
			if(returnVal.indexOf("<") != -1){
				returnVal = returnVal.split("<").join("&#60;");
			}
		
			showTime("API.LMSGetValue", gname,  returnVal, startTime, endTime)
       		 /////////////
		return ret1;		
	}	
};

function commit()
{
	GetAPI();
	if( API != null )
	{
		var ret = "";
		var sTime = new Date().getTime();
		var comRet=API.LMSCommit("");
		//=========================
		var eTime = new Date().getTime();
		showTime("API.LMSCommit", " ",  comRet, sTime, eTime)
		//fnDebuggerSetData(strToFlash, "other")		
	}
	
};

	
function finish(){
	try {
		GetAPI();
		if( API != null ){
			computeTime();
			commit()
			var ret = API.LMSFinish("");
			top.close();
		}
	} catch (err) {
	}
};

function startTimer()
{
	startDate = new Date().getTime();
}

	
function computeTime()
{
	if ( startDate != 0 )
	{
	      var currentDate = new Date().getTime();
	      var elapsedSeconds = ( (currentDate - startDate) / 1000 );
	      var formattedTime = convertTotalSeconds( elapsedSeconds );
	}
	else
	{
	      formattedTime = "00:00:00.0";
	}
	set_val( "cmi.core.session_time", formattedTime );
}
	
function showTime(func, callStr, rValue, sTime, eTime, setValue){	
	//alert("func: "+func+", "+"callStr: "+callStr+", "+"rValue: "+rValue+", "+"sTime: "+sTime+", "+"eTime: "+eTime+", "+"setValue: "+setValue)
	var elapsedSeconds = ( (eTime-sTime) / 1000 );
	if(func=="API.LMSSetValue"){	
		strToFlash = "Function: "+func +"<br>Parameters: ("+callStr+",  "+setValue+")<br>Return Value: "+rValue+"<br>Elapsed Time: "+elapsedSeconds+"<br>Start Time: "+sTime+"<br>End Time: "+eTime+"<br>";
		
		fnDebuggerSetData(strToFlash, "set")

	}else if(func=="API.LMSGetValue"){
		strToFlash = "Function: "+func +"<br>Parameters: ("+callStr+")<br>Return Value: "+rValue+"<br>Elapsed Time: "+elapsedSeconds+"<br>Start Time: "+sTime+"<br>End Time: "+eTime+"<br>";
		fnDebuggerSetData(strToFlash, "get")
	}else{
		strToFlash = "Function: "+func +"<br>Parameters: ("+callStr+")<br>Return Value: "+rValue+"<br>Elapsed Time: "+elapsedSeconds+"<br>Start Time: "+sTime+"<br>End Time: "+eTime+"<br>";
		fnDebuggerSetData(strToFlash, "other")
	}	
}

function convertTotalSeconds(ts)
{
	 var sec = (ts % 60);
	
	 ts -= sec;
	 var tmp = (ts % 3600);  //# of seconds in the total # of minutes
	 ts -= tmp;              //# of seconds in the total # of hours
	
	 // convert seconds to conform to CMITimespan type (e.g. SS.00)
	 sec = Math.round(sec*100)/100;
	   
	 var strSec = new String(sec);
	 var strWholeSec = strSec;
	 var strFractionSec = "";
	
	 if (strSec.indexOf(".") != -1)
	 {
	      strWholeSec =  strSec.substring(0, strSec.indexOf("."));
	      strFractionSec = strSec.substring(strSec.indexOf(".")+1, strSec.length);
	 }
	   
	 if (strWholeSec.length < 2)
	 {
	      strWholeSec = "0" + strWholeSec;
	 }
	 strSec = strWholeSec;
	   
	 if (strFractionSec.length)
	 {
	      strSec = strSec+ "." + strFractionSec;
	 }
	
	
	 if ((ts % 3600) != 0 )
	      var hour = 0;
	 else var hour = (ts / 3600);
	 if ( (tmp % 60) != 0 )
	      var min = 0;
	 else var min = (tmp / 60);
	
	 if ((new String(hour)).length < 2)
	      hour = "0"+hour;
	 if ((new String(min)).length < 2)
	      min = "0"+min;
	
	 var rtnVal = hour+":"+min+":"+strSec;
	 return rtnVal;
}


function fnGetStudentData()
{
	student_name=fnGetStudentName();
	lesson_location=String(fnGetLessonLocation());
	if(lesson_location.indexOf('|')==-1)
		lesson_location='undefined'
	std_data=student_name+"$"+lesson_location;

	//////////////
	DebugContent += "student_name : " + student_name;
	DebugContent += "lesson_location : " + lesson_location;
		
	trace(DebugContent);
       	/////////////
	return(std_data);
	
}
	
function fnGetStudentName()
{
	//alert(get_val("cmi.core.student_name"))
	return(get_val("cmi.core.student_name"))
	//return("ani")
}


function fnGetLessonLocation()
{
	//alert("get lesson location "+get_val("cmi.core.lesson_location"))
	return(get_val("cmi.core.lesson_location"))
}

function fnGetScore()
{
	//alert("get Score "+get_val("cmi.core.score.raw"))
	oldScore = get_val("cmi.core.score.raw")
	if (oldScore == ""){
		oldScore = 0
	}
	return(oldScore)
}

function fnGetVSection()
{
	//alert("get visited data "+get_val("cmi.suspend_data"))	
	//alert("cmi.suspend_data : " + get_val("cmi.suspend_data"));
	
	return(get_val("cmi.suspend_data"))
}


function fnSetVal(setval)
{	
	var setData = setval.split("~");

	fnSetLessonInfo(setData[0]);
	fnSetLessonStatus(setData[1]);
	fnSetScore(setData[2]);
	//fnSetVSection(setData[3]);

	//////////////
	DebugContent += "SetLessonInfo : " + setData[0] + " : ";
	DebugContent += "SetLessonStatus : " + setData[1] + " : ";
	DebugContent += "SetScore : " + setData[2] + " : ";
	DebugContent += "SetVSection : " + setData[3] + " : ";
		
	trace(DebugContent);
       	/////////////
}
function fnSetLessonInfo(lsnInfo)
{
	set_val("cmi.core.lesson_location",lsnInfo);
	//commit();
	//alert(" lessonInfo "+lsnInfo)
}
function fnSetLessonStatus(lsnStatus1) 
{
	if(lsnStatus1 != "incomplete"){
		set_val("cmi.core.lesson_status",lsnStatus1);
	}
	//commit();
	//alert(" lsnStatus1 "+lsnStatus1)
}
function fnSetScore(totalScore)
{
	var newScore=Number(totalScore)
	//var oldScore=Number(fnGetScore())
	
	if (newScore == 0){
		newScore="0"
		set_val("cmi.core.score.raw",newScore);
	}else {
		set_val("cmi.core.score.raw",newScore);
	}
	//commit();
}
function fnSetVSection(vLesson)
{
	set_val("cmi.suspend_data",vLesson);
	
	if(alreadyCompleted == false && resultPageGlobal == true){
		commit();
	}
	
}

function sendLMSData(userData){
	//alert("SCORM API: "+userData)
	var userScore=0
	
	var  userData_Arr=userData.split("^^^^")
		
	var flag=true
	var courseStatus=false
	var resultPage=false
	for(var i=0;i<userData_Arr.length;i++){
		if(userData_Arr[i]!="undefined"){
			var userData_Array=userData_Arr[i].split("#")
			userScore+=Number(userData_Array[3])
			courseStatus=userData_Array[4]
			resultPage=userData_Array[5]
			if(userData_Array[2]=="false"){
				flag=false
				break
			}
		}else{
			flag=false
			break
		}
	
	}
	

	if(courseStatus=="true"){
		flag=false
	}
	
	var scoreAvg=Math.round(userScore/userData_Arr.length)
	if(resultPage=="true"){
		resultPageGlobal = true
		fnSetScore(scoreAvg)
		if(Number(scoreAvg)>=Number(mastery_score)){
			status="completed"
		}else{
			status="";
		}			
	}else{
		resultPageGlobal = false
	}
	if(flag){
		var myStatus="completed"
		fnSetLessonStatus(myStatus)
			
	}
	
	var uData_arr=userData.split("#")
	fnSetVSection(uData_arr.slice(0,4).join("#")+"$$$"+status)	
	
}
/* Old function commented to send new post assessment interaction
function sendInteractionsData(qText, time, id, obj_id, type, corr_resp, stud_resp, result, weighting, latency, seq){
	//MM_cmiSendInteractionInfo(qText, date, time, intid, objid, intrtype,correct, student, result, weight, latency)
	//alert(seq+" : "+id+" : "+qText)
	if(type=="MTF"){
		type="matching"
	}else if(type=="MCQ" || type=="MMCQ"){
		type="choice"
	}else if(type=="DND"){
		type="sequencing"
	}else if(type=="FIB"){
		type="fill-in"
	}
	if(result=="1"){
		result="correct"
	}else{
		result="wrong"
	}
	//alert(qText)
	var n = get_val("cmi.interactions._count");
	qText=qText.split("#apostrophe#").join("'")
	//alert(qText)
	set_val("cmi.interactions." + n + ".objectives", qText);
	set_val("cmi.interactions." + n + ".time", time);
	set_val("cmi.interactions." + n + ".id", id);
	set_val("cmi.interactions." + n + ".objectives.0.id",obj_id);
	set_val("cmi.interactions." + n + ".type",type);
	set_val("cmi.interactions." + n + ".correct_responses.0.pattern", corr_resp);
	set_val("cmi.interactions." + n + ".student_response", stud_resp);
	set_val("cmi.interactions." + n + ".result", result);
	set_val("cmi.interactions." + n + ".weighting", weighting);
	set_val("cmi.interactions." + n + ".latency", latency);
	commit();
}*/
function sendInteractionsData(qText, time, id, obj_id, type, corr_resp, stud_resp, result, weighting, latency, seq){
	//MM_cmiSendInteractionInfo(qText, date, time, intid, objid, intrtype,correct, student, result, weight, latency)
	//alert(seq+" : "+id+" : "+qText)
	if(type=="MTF" || type=="DDM"){
		type="matching"
	}else if(type=="MCQ" || type=="MMCQ"){
		type="choice"
	}else if(type=="DND"){
		type="sequencing"
	}else if(type=="FIB"){
		type="fill-in"
	}else if(type=="SEQ"){
		type="sequencing"
	}
	if(result=="1"){
		result="correct"
	}else{
		result="wrong"
	}
	//alert(qText)
	var n = get_val("cmi.interactions._count");
	qText=qText.split("#apostrophe#").join("'")
	//alert(qText)
	set_val("cmi.interactions." + n + ".objectives", qText);
	set_val("cmi.interactions." + n + ".time", time);
	set_val("cmi.interactions." + n + ".id", id);
	set_val("cmi.interactions." + n + ".objectives.0.id",obj_id);
	set_val("cmi.interactions." + n + ".type",type);
	set_val("cmi.interactions." + n + ".correct_responses.0.pattern", corr_resp);
	set_val("cmi.interactions." + n + ".student_response", stud_resp);
	set_val("cmi.interactions." + n + ".result", result);
	set_val("cmi.interactions." + n + ".weighting", weighting);
	set_val("cmi.interactions." + n + ".latency", latency);
	commit();
}