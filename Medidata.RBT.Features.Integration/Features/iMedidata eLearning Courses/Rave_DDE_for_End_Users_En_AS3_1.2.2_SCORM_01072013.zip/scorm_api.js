//----------------------------------- Javascript Code for SCORM type course ----------------------------------------------//
var Ap;
var findAPITries=1;
var API = null;
var lsnInfo = null;
var lsnStatus;
var totalScore;
var oldScore;
var vLesson;
var mastery_score;
var inatrval;
var DebugContent
var flashObj;
var status="";
var seperator = "<br>=====================================================================<br>";
var resultPageGlobal = false
var alreadyCompleted = false
function trace(content)//
{
	return;
	debugWin1 = window.open("", "debugWin1", "menubar=no, fullscreen=no, width=500, height=300, scrollbars=yes,resize=yes")
	debugWin1.resizeTo(screen.width, 400);	
	debugWin1.document.open();
	debugWin1.document.write(content);
	//debugWin.document.close();	
}

function FindAPI(win){	
   while ((win.API == null) && (win.parent != null) && (win.parent != win)){
      findAPITries++;
      // Note: 7 is an arbitrary number, but should be more than sufficient
      if (findAPITries > 7){
        parent.status = "Error finding API -- too deeply nested.";       
		return null;
	}else{
	//////////////	
     }
      win = win.parent;
   }
   return win.API;
}

function GetAPI(){
	var sTime = new Date().getTime();
	var API = FindAPI(window); 
	if ((API == null) && (window.opener != null) && (typeof(window.opener) != "undefined")){
      API = FindAPI(window.opener);
	}if (API == null){
     parent.status = "Unable to find an API adapter";
	}
	
	//code below is for displaying the set data in debugger window//
	var eTime = new Date().getTime();
	var elapsedTime=((eTime-sTime)/1000)
	strToFlash = "Function: GetAPI <br>API: "+API+"<br>Elapsed Time: "+elapsedTime+"<br>Start Time: "+sTime+"<br>End Time: "+eTime+"<br>"
	fnDebuggerSetData(strToFlash, "other")
	//code above is for displaying the set data in debugger window//	
   return API
 }
 
function initSco(){
	if (document.all){
		flashObj = document.getElementById("shell");
	}else{
		flashObj = document.shell;
	}
	API = GetAPI();
	
	if( API != null )	{
		
		//code below is for displaying the set data in debugger window//
		var startTime = new Date().getTime();
		var retValue = API.LMSInitialize("");	
		var endTime = new Date().getTime();
		showTime("API.LMSInitialize", " ",  retValue, startTime, endTime)		
		//code above is for displaying the set data in debugger window//		
		startTimer();		
		set_val("cmi.core.session_time","0000:00:00");		
		mastery_score = get_val("cmi.student_data.mastery_score");		
		if(mastery_score=="" || mastery_score== null){
			mastery_score=80;
		}
		set_val("cmi.core.lesson_status","incomplete");
		
		lsnStatus = "incomplete"

		suspendData=fnGetVSection()
		tmp_arr=suspendData.split("$$$")
		suspendData=tmp_arr[0]
		status=tmp_arr[1]

		intFlash();

	}else{	
		//intFlash();	
		flashObj.setFlashVar("lmsInitData", "true")
	}
	
}
function intFlash(){	
	flashObj.setFlashVar("lmsSuspendData", suspendData);
	flashObj.setFlashVar("lmsLessonStatus", status);
	//flashObj.setFlashVar("lmsSuspendData", "111110100000000#1_5#false#0^^^^111111100000011#1_5#true#0")
	flashObj.setFlashVar("lmsStudentMasteryScore", mastery_score);
	flashObj.setFlashVar("lmsInitData", "true");
	flashObj.setFlashVar("lmsStudentName", fnGetStudentName());	
}

function set_val( gname,gvalue ){	
	if(gvalue == null || gvalue == "undefined" || gvalue == ""){
		return;
	}
	GetAPI();
	if( API != null ){
		var ret;
		var code;
		var diag;	
		var startTime = new Date().getTime();
		ret = API.LMSSetValue( gname, gvalue );		
		//code below is for displaying the set data in debugger window//
		var endTime = new Date().getTime();
		if(gvalue.indexOf("<") != -1){
			gvalue = gvalue.split("<").join("&#60;");
		}
		showTime("API.LMSSetValue", gname,  ret, startTime, endTime, gvalue)
		//code above is for displaying the set data in debugger window//		
	}
			
};

function get_val(gname){	
if (gname=="cmi.core.session_time") return "00:00:00";
	GetAPI();
	if( API != null ){
		var ret1,ret2;
		var code;
		var diag;	
		var startTime = new Date().getTime();		
		ret1 = API.LMSGetValue( gname );	
		//code added for external debugger//
		var endTime = new Date().getTime();
		var returnVal = String(ret1);		
		if(returnVal.indexOf("<") != -1){
			returnVal = returnVal.split("<").join("&#60;");
		}
		showTime("API.LMSGetValue", gname,  returnVal, startTime, endTime);	
		//code above is for displaying the set data in debugger window//			
		return ret1;		
	}	
};

function commit(){
	GetAPI();
	if( API != null ){
		//code below is for displaying the set data in debugger window//
		var sTime = new Date().getTime();
		var comRet=API.LMSCommit("");
		var eTime = new Date().getTime();
		showTime("API.LMSCommit", " ",  comRet, sTime, eTime)
		//code above is for displaying the set data in debugger window//
	}	
};

function finish(){
	try {
		GetAPI();
		if( API != null ){
			computeTime();
			commit()
			var ret = API.LMSFinish("");
			top.close();
		}
	} catch (err) {
	}
};

function startTimer(){
	startDate = new Date().getTime();
}
	
function computeTime(){
	if ( startDate != 0 ){
	      var currentDate = new Date().getTime();
	      var elapsedSeconds = ( (currentDate - startDate) / 1000 );
	      var formattedTime = convertTotalSeconds( elapsedSeconds );
	}else{
	      formattedTime = "00:00:00.0";
	}
		set_val( "cmi.core.session_time", formattedTime );
}

function showTime(func, callStr, rValue, sTime, eTime, setValue){			
	var elapsedSeconds = ( (eTime-sTime) / 1000 );
	if(func=="API.LMSSetValue"){	
		strToFlash = "Function: "+func +"<br>Parameters: ("+callStr+",  "+setValue+")<br>Return Value: "+rValue+"<br>Elapsed Time: "+elapsedSeconds+"<br>Start Time: "+sTime+"<br>End Time: "+eTime+"<br>";
		fnDebuggerSetData(strToFlash, "set")
	}else if(func=="API.LMSGetValue"){
		strToFlash = "Function: "+func +"<br>Parameters: ("+callStr+")<br>Return Value: "+rValue+"<br>Elapsed Time: "+elapsedSeconds+"<br>Start Time: "+sTime+"<br>End Time: "+eTime+"<br>";
		fnDebuggerSetData(strToFlash, "get")
	}else{
		strToFlash = "Function: "+func +"<br>Parameters: ("+callStr+")<br>Return Value: "+rValue+"<br>Elapsed Time: "+elapsedSeconds+"<br>Start Time: "+sTime+"<br>End Time: "+eTime+"<br>";
		fnDebuggerSetData(strToFlash, "other")
	}	
}
	
function convertTotalSeconds(ts){
	 var sec = (ts % 60);	
	 ts -= sec;
	 var tmp = (ts % 3600);  //# of seconds in the total # of minutes
	 ts -= tmp;              //# of seconds in the total # of hours	
	 // convert seconds to conform to CMITimespan type (e.g. SS.00)
	 sec = Math.round(sec*100)/100;	   
	 var strSec = new String(sec);
	 var strWholeSec = strSec;
	 var strFractionSec = "";	
	 if (strSec.indexOf(".") != -1){
	      strWholeSec =  strSec.substring(0, strSec.indexOf("."));
	      strFractionSec = strSec.substring(strSec.indexOf(".")+1, strSec.length);
	 }	   
	 if (strWholeSec.length < 2){
	      strWholeSec = "0" + strWholeSec;
	 }
	 strSec = strWholeSec;	   
	 if (strFractionSec.length){
	      strSec = strSec+ "." + strFractionSec;
	 }	
	 
	 if ((ts % 3600) != 0 )
	 var hour = 0;
	 else var hour = (ts / 3600);
	 
	 if ( (tmp % 60) != 0 )
	      var min = 0;
	 else var min = (tmp / 60);
	
	 if ((new String(hour)).length < 2)
	      hour = "0"+hour;
	 if ((new String(min)).length < 2)
	      min = "0"+min;
	 var rtnVal = hour+":"+min+":"+strSec;
	 return rtnVal;
}

function fnGetStudentData(){
	student_name=studentName
	lesson_location=String(fnGetLessonLocation());
	if(lesson_location.indexOf('|')==-1)
	lesson_location='undefined'
	std_data=student_name+"$"+lesson_location;
	//////////////
	DebugContent += "student_name : " + student_name;
	DebugContent += "lesson_location : " + lesson_location;		
	return(std_data);	
}
	
function fnGetStudentName(){
	var returnVal = "Guest";
	var studentName=get_val("cmi.core.student_name");
	if(String(studentName) != "undefined" && String(studentName) != "null"){
		returnVal = studentName
	}
	return returnVal;
}

function fnGetLessonLocation(){
	return(get_val("cmi.core.lesson_location"))
}

function fnGetScore(){
	oldScore = get_val("cmi.core.score.raw")
	if (oldScore == ""){
		oldScore = 0
	}
	return(oldScore)
}

function fnGetVSection(){
	return(get_val("cmi.suspend_data"))
}

function fnSetVal(setval){	
	var setData = setval.split("~");
	fnSetLessonInfo(setData[0]);
	fnSetLessonStatus(setData[1]);
	fnSetScore(setData[2]);
	//fnSetVSection(setData[3]);		
}
function fnSetLessonInfo(lsnInfo){
	set_val("cmi.core.lesson_location",lsnInfo);
	//commit();
}
function fnSetLessonStatus(lsnStatus1){
	if(lsnStatus1 != "incomplete"){
		set_val("cmi.core.lesson_status",lsnStatus1);
	}
	//commit();
}
function fnSetScore(totalScore)
{
	var newScore=String(totalScore)
	//var oldScore=Number(fnGetScore())
	
	if (newScore == 0){
		newScore="0"
		set_val("cmi.core.score.raw",newScore);
	}else {
		set_val("cmi.core.score.raw",newScore);
	}
	//commit();
}
function fnSetVSection(vLesson)
{
	set_val("cmi.suspend_data",vLesson);
	//alert("Set Suspend Data: "+vLesson)
	if(alreadyCompleted == false && resultPageGlobal == true){
		commit();
		//alert("Commit called.")
	}
	//alert('set suspend : ' + vLesson + ' ::: ' + get_val("cmi.suspend_data"));
	//alert(" Score "+totalScore)
}


function sendLMSData(userData){	
	//userData = visitedFrames#bookmark#CourseStatus#score#resultPage//
	var userScore=0	
	var  userData_Arr=userData.split("^^^^")
	var flag=true
	var courseStatus=false
	var resultPage=false
	
	for(var i=0;i<userData_Arr.length;i++){
		if(userData_Arr[i]!="undefined"){
			var userData_Array=userData_Arr[i].split("#")
			userScore+=Number(userData_Array[3])
			courseStatus=userData_Array[2]
			resultPage=userData_Array[4]
			if(userData_Array[2]=="false"){
				flag=false
				//break
			}
		}else{
			flag=false
			//break
		}	
	}
	
	/*
	if(courseStatus=="true"){
		flag=false
	}*/
	var scoreAvg=Math.round(userScore/userData_Arr.length)
	if(resultPage=="true"){
		resultPageGlobal = true
		fnSetScore(scoreAvg)
		if(Number(scoreAvg)>=Number(mastery_score)){
			status="completed"
		}else{
			status="";
		}	
	}else{
		resultPageGlobal = false
	}
	
	if(flag){
		var myStatus="completed"
		fnSetLessonStatus(myStatus)			
	}
	var tempStr="";
	var tempCount=0;
	for(var j=0; j < userData_Arr.length; j++){
		if(userData_Arr[j] != "undefined"){			
			var uData_arr = userData_Arr[j].split("#")
			var uData_arr1 = uData_arr.slice(0,4).join("#");
			if(tempCount > 0){
				tempStr += "^^^^"+uData_arr1;
			}else{
				tempStr += uData_arr1
			}			
			tempCount++
		}
	}
	fnSetVSection(tempStr+"$$$"+status)		
}

function sendInteractionsData(qText, time, id, type, corr_resp, stud_resp, result, latency, seq){
	if(type=="MTF" || type=="DDM"){
		type="matching"
	}else if(type=="MCQ" || type=="MMCQ"){
		type="choice"
	}else if(type=="DND"){
		type="sequencing"
	}else if(type=="FIB"){
		type="fill-in"
	}else if(type=="SEQ"){
		type="sequencing"
	}
	if(result=="1"){
		result="correct"
	}else{
		result="wrong"
	}
	var n = get_val("cmi.interactions._count");
	qText=qText.split("#apostrophe#").join("'")
	stud_resp=unescape(stud_resp);
	set_val("cmi.interactions." + n + ".objectives", qText);
	set_val("cmi.interactions." + n + ".time", time);
	set_val("cmi.interactions." + n + ".id", id);
	//set_val("cmi.interactions." + n + ".objectives.0.id",obj_id);
	set_val("cmi.interactions." + n + ".type",type);
	set_val("cmi.interactions." + n + ".correct_responses.0.pattern", corr_resp);
	set_val("cmi.interactions." + n + ".student_response", stud_resp);
	set_val("cmi.interactions." + n + ".result", result);
	//set_val("cmi.interactions." + n + ".weighting", weighting);
	set_val("cmi.interactions." + n + ".latency", latency);
	commit();
}
//this function will get the latest data from scrom and sen
function getScormDebuggerData(){	
	flashObj.setFlashDebugVar("lmsSuspendData", fnGetVSection())
	flashObj.setFlashDebugVar("lmsStudentMasteryScore", get_val("cmi.student_data.mastery_score"));	
	flashObj.setFlashDebugVar("lesson_status", get_val("cmi.core.lesson_status"));
	flashObj.setFlashDebugVar("lmsStudentName", studentName);
	flashObj.setFlashDebugVar("lmsInitData", "true");
}

//----------------------------------- Javascript Code for Rave and Rave External type course ----------------------------------------------//
	//--- setting data to database//
function setRaveData(courseType, Score, CourseStatus, CompletedData, PostAssessmentData){
		var tempStr="";
		var tempCount=0;
		userData_Arr  = CompletedData.split("^^^^")
		for(var j=0; j < userData_Arr.length; j++){
			if(userData_Arr[j] != "undefined"){	
				if(tempCount > 0){
					tempStr += "^^^^"+userData_Arr[j];
				}else{
					tempStr += userData_Arr[j]
				}			
				tempCount++
			}
		}
		CompletedData = tempStr
		//creating page url based on course Type//
		var pageURL = "";		
		if (courseType == "rave") {
				pageURL = "PutData.aspx";
			} else {
				pageURL = "../../../PutData.aspx";
		}
		//storing the sent data  in a string to display in debugger window//
		var debugString =  "<b>Score</b> --------------> "+ Score +"<br>";
			debugString += "<b>CourseStatus</b> --------------> "+ CourseStatus +"<br>";
			debugString += "<b>CompletedData</b> --------------> "+ CompletedData +"<br>";
			debugString += "<b>PostAssessmentData</b> --------------> "+ PostAssessmentData +"<br>";
			fnDebuggerSetData(debugString, "set")
		//posting data to Rave database//
		$.post(pageURL, {Score:Score,CourseStatus:CourseStatus,CompletedData:CompletedData,PostAssessmentData:PostAssessmentData});
}

//getting data from rave server using jQuery//
function getRaveData(courseType){
		//next line is for degugging purpose only//
		var sTime = new Date().getTime();
		if (document.all){
			flashObj = document.getElementById("shell");
		}else{
			flashObj = document.shell;
		}
		var pageURL = "";		
		if (courseType == "rave") {
				pageURL = "Getdata.aspx";
			} else {
				pageURL = "../../../Getdata.aspx";
		}						
		$.ajax({
			type: "post", url: pageURL,
			success: function (data) {
			flashObj.onRaveDataLoaded(data);
			parseAndDisplayRaveReceivedData(data)		
		},
		error: function (request, status, error) {
			flashObj.onRaveIOError(String(error));
			//parseAndDisplayRaveReceivedData("Error in loading rave data")		
			fnDebuggerSetData(String(error), "get")
		}
	});
 }
 //This function is parsing the data received from Rave to display in Debugger window//
 function parseAndDisplayRaveReceivedData(data){
	var varsArray = String(data).split("&");
	var debugString = "";
	for(var i=0; i<varsArray.length; i++){
		if(String(varsArray[i]) != ""){
			debugString += "<b>"+String(varsArray[i]).split("=")[0]+"</b> -------------->"+String(varsArray[i]).split("=")[1] + "<br>";
		}
	}
	fnDebuggerSetData(debugString, "get")
 }
 
function checkSessionForRave(courseType){
		//next line is for degugging purpose only//
		if (document.all){
			flashObj = document.getElementById("shell");
		}else{
			flashObj = document.shell;
		}
		var sTime = new Date().getTime();
		var pageURL = "";		
		if (courseType == "rave") {
				pageURL = "Getdata.aspx";
			} else {
				pageURL = "../../../Getdata.aspx";
		}						
		$.ajax({
			type: "post", url: pageURL,
			success: function (data) {
			flashObj.onRaveSessionDataLoaded(data)						
			parseAndDisplayRaveReceivedData(data)		
		},
		error: function (request, status, error) {				
			flashObj.onRaveSessionIOError(String(error))			
			fnDebuggerSetData(String(error), "get")
		
		}
	});
}